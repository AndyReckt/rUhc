package io.github.thatkawaiisam.utils;

import org.bukkit.*;
import java.util.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.*;

public class PlayerHeadUtility
{
    private Material material;
    private Short durability;
    private int amount;
    private String title;
    private String owner;
    private List<String> lores;
    
    public PlayerHeadUtility() {
        this.material = Material.SKULL_ITEM;
        this.durability = 3;
        this.amount = 1;
        this.owner = "steve";
    }
    
    public PlayerHeadUtility title(final String title) {
        this.title = title;
        return this;
    }
    
    public PlayerHeadUtility owner(final String owner) {
        this.owner = owner;
        return this;
    }
    
    public PlayerHeadUtility lores(final List<String> lores) {
        this.lores = lores;
        return this;
    }
    
    public ItemStack build() {
        final ItemStack itemStack = new ItemStack(Material.SKULL_ITEM);
        final SkullMeta meta = (SkullMeta)itemStack.getItemMeta();
        itemStack.setAmount(1);
        itemStack.setDurability((short)3);
        if (this.title != null) {
            meta.setDisplayName(MessageUtility.formatMessage("&r" + this.title));
        }
        if (this.lores != null && this.lores.size() > 0) {
            meta.setLore((List)MessageUtility.formatMessages(this.lores));
        }
        meta.setOwner(this.owner);
        itemStack.setItemMeta((ItemMeta)meta);
        return itemStack;
    }
}
