package io.github.thatkawaiisam.utils;

import org.bukkit.entity.*;
import io.github.thatkawaiisam.utils.serverversion.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import org.bukkit.inventory.*;

public class PlayerUtility
{
    public static String getPlayerLanguage(final Player player) {
        return ServerVersionHandler.version.getPlayerLanguage(player);
    }
    
    public static void clearArrowsFromPlayer(final Player player) {
        ServerVersionHandler.version.clearArrowsFromPlayer(player);
    }
    
    public static PlayerVersion getPlayerVersion(final Player player) {
        return PlayerVersionHandler.version.getPlayerVersion(player);
    }
    
    public static void clearInventory(final Player player) {
        player.getInventory().clear();
        player.getInventory().setArmorContents((ItemStack[])null);
    }
}
