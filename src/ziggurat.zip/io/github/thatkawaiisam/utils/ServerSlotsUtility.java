package io.github.thatkawaiisam.utils;

import java.lang.reflect.*;
import org.bukkit.*;

public class ServerSlotsUtility
{
    private static final String CRAFT_BUKKIT_PACKAGE;
    private static final String NET_MINECRAFT_SERVER_PACKAGE;
    private static final Class CRAFT_SERVER_CLASS;
    private static final Method CRAFT_SERVER_GET_HANDLE_METHOD;
    private static final Class PLAYER_LIST_CLASS;
    private static final Field PLAYER_LIST_MAX_PLAYERS_FIELD;
    
    public static void setMaxPlayers(final Server server, final int slots) {
        try {
            ServerSlotsUtility.PLAYER_LIST_MAX_PLAYERS_FIELD.set(ServerSlotsUtility.CRAFT_SERVER_GET_HANDLE_METHOD.invoke(server, new Object[0]), slots);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    static {
        try {
            final String version = Bukkit.getServer().getClass().getPackage().getName().replace(".", ",").split(",")[3];
            CRAFT_BUKKIT_PACKAGE = "org.bukkit.craftbukkit." + version + ".";
            NET_MINECRAFT_SERVER_PACKAGE = "net.minecraft.server." + version + ".";
            CRAFT_SERVER_CLASS = Class.forName(ServerSlotsUtility.CRAFT_BUKKIT_PACKAGE + "CraftServer");
            (CRAFT_SERVER_GET_HANDLE_METHOD = ServerSlotsUtility.CRAFT_SERVER_CLASS.getDeclaredMethod("getHandle", (Class[])new Class[0])).setAccessible(true);
            PLAYER_LIST_CLASS = Class.forName(ServerSlotsUtility.NET_MINECRAFT_SERVER_PACKAGE + "PlayerList");
            (PLAYER_LIST_MAX_PLAYERS_FIELD = ServerSlotsUtility.PLAYER_LIST_CLASS.getDeclaredField("maxPlayers")).setAccessible(true);
        }
        catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to initialize Bukkit/NMS Reflection");
        }
    }
}
