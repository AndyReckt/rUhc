package io.github.thatkawaiisam.utils;

import org.apache.commons.io.*;
import org.bukkit.*;
import java.io.*;

public class WorldUtility
{
    public static void copyWorld(final String oldDirectory, final String newDirectory, final String name) {
        try {
            final File dest = new File("./" + newDirectory + "/" + name);
            final File source = new File("./" + oldDirectory + "/");
            FileUtils.copyDirectory(source, dest);
            Bukkit.createWorld(new WorldCreator(name));
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void deleteWorld(final String directory, final String world) {
        Bukkit.unloadWorld(world, true);
        final File dir = new File("./" + directory + world);
        try {
            FileUtils.deleteDirectory(dir);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
