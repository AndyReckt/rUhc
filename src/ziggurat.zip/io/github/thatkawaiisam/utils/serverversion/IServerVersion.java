package io.github.thatkawaiisam.utils.serverversion;

import org.bukkit.entity.*;

public interface IServerVersion
{
    void clearArrowsFromPlayer(final Player p0);
    
    String getPlayerLanguage(final Player p0);
}
