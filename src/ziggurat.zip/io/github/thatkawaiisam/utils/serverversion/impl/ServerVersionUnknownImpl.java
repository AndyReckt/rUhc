package io.github.thatkawaiisam.utils.serverversion.impl;

import io.github.thatkawaiisam.utils.serverversion.*;
import org.bukkit.entity.*;

public class ServerVersionUnknownImpl implements IServerVersion
{
    @Override
    public void clearArrowsFromPlayer(final Player player) {
    }
    
    @Override
    public String getPlayerLanguage(final Player player) {
        return "en";
    }
}
