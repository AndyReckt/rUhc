package io.github.thatkawaiisam.utils.serverversion.impl;

import io.github.thatkawaiisam.utils.serverversion.*;
import org.bukkit.entity.*;
import org.bukkit.craftbukkit.v1_8_R3.entity.*;

public class ServerVersion1_8_R3Impl implements IServerVersion
{
    @Override
    public void clearArrowsFromPlayer(final Player player) {
        ((CraftPlayer)player).getHandle().getDataWatcher().watch(9, (Object)0);
    }
    
    @Override
    public String getPlayerLanguage(final Player player) {
        return ((CraftPlayer)player).getHandle().locale.substring(0, 2);
    }
}
