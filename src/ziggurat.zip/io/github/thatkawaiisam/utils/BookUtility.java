package io.github.thatkawaiisam.utils;

import java.util.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import org.bukkit.inventory.meta.*;

public class BookUtility
{
    private String title;
    private String author;
    private List<String> pages;
    
    public BookUtility title(final String title) {
        this.title = title;
        return this;
    }
    
    public BookUtility author(final String author) {
        this.author = author;
        return this;
    }
    
    public BookUtility pages(final List<String> pages) {
        this.pages = pages;
        return this;
    }
    
    public ItemStack build() {
        final ItemStack book = new ItemStack(Material.WRITTEN_BOOK);
        final BookMeta bookMeta = (BookMeta)book.getItemMeta();
        if (this.author != null) {
            bookMeta.setAuthor(this.author);
        }
        if (this.title != null) {
            bookMeta.setTitle(this.title);
        }
        if (this.pages != null) {
            this.pages.forEach(string -> bookMeta.addPage(new String[] { MessageUtility.formatMessage("&r" + string) }));
        }
        book.setItemMeta((ItemMeta)bookMeta);
        return book;
    }
}
