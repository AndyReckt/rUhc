package io.github.thatkawaiisam.utils;

import org.bukkit.plugin.java.*;
import org.bukkit.map.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.*;
import java.net.*;
import javax.imageio.*;
import java.io.*;
import java.awt.*;
import java.awt.image.*;
import org.bukkit.plugin.*;

public class MapUtility
{
    public static void createNewMap(final JavaPlugin javaPlugin, final MapView mapView, final MapView.Scale scale) {
        mapView.setScale(scale);
        mapView.getRenderers().clear();
        mapView.addRenderer((MapRenderer)new CustomRender(javaPlugin));
    }
    
    public static class CustomRender extends MapRenderer
    {
        private JavaPlugin plugin;
        
        public CustomRender(final JavaPlugin plugin) {
            this.plugin = plugin;
        }
        
        public void render(final MapView mapView, final MapCanvas mapCanvas, final Player player) {
            new BukkitRunnable() {
                public void run() {
                    BufferedImage image = null;
                    try {
                        image = ImageIO.read(new URL("http://www.newdesignfile.com/postpic/2015/02/mario-128x128-icon_245367.png"));
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                    mapCanvas.drawImage(0, 0, (Image)image);
                }
            }.runTaskAsynchronously((Plugin)this.plugin);
        }
    }
}
