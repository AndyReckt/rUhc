package io.github.thatkawaiisam.utils;

import java.lang.reflect.*;
import org.bukkit.entity.*;

public class PingUtility
{
    private static Method getHandleMethod;
    private static Field pingField;
    
    public static int getPing(final Player player) {
        try {
            if (PingUtility.getHandleMethod == null) {
                (PingUtility.getHandleMethod = player.getClass().getDeclaredMethod("getHandle", (Class<?>[])new Class[0])).setAccessible(true);
            }
            final Object entityPlayer = PingUtility.getHandleMethod.invoke(player, new Object[0]);
            if (PingUtility.pingField == null) {
                (PingUtility.pingField = entityPlayer.getClass().getDeclaredField("ping")).setAccessible(true);
            }
            final int ping = PingUtility.pingField.getInt(entityPlayer);
            return (ping > 0) ? ping : 0;
        }
        catch (Exception e) {
            return 1;
        }
    }
}
