package io.github.thatkawaiisam.utils.playerversion.impl;

import org.bukkit.entity.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import org.bukkit.craftbukkit.v1_7_R4.entity.*;

public class PlayerVersion1_7Impl implements IPlayerVersion
{
    @Override
    public PlayerVersion getPlayerVersion(final Player player) {
        return PlayerVersion.getVersionFromRaw(((CraftPlayer)player).getHandle().playerConnection.networkManager.getVersion());
    }
}
