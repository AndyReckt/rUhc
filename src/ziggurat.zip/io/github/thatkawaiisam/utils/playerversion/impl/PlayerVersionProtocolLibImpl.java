package io.github.thatkawaiisam.utils.playerversion.impl;

import org.bukkit.entity.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import com.comphenix.protocol.*;

public class PlayerVersionProtocolLibImpl implements IPlayerVersion
{
    @Override
    public PlayerVersion getPlayerVersion(final Player player) {
        return PlayerVersion.getVersionFromRaw(ProtocolLibrary.getProtocolManager().getProtocolVersion(player));
    }
}
