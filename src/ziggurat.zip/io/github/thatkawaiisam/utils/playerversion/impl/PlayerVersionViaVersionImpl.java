package io.github.thatkawaiisam.utils.playerversion.impl;

import org.bukkit.entity.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import us.myles.ViaVersion.api.*;

public class PlayerVersionViaVersionImpl implements IPlayerVersion
{
    @Override
    public PlayerVersion getPlayerVersion(final Player player) {
        return PlayerVersion.getVersionFromRaw(Via.getAPI().getPlayerVersion(player));
    }
}
