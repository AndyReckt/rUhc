package io.github.thatkawaiisam.utils.playerversion.impl;

import org.bukkit.entity.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import protocolsupport.api.*;

public class PlayerVersionProtocolSupportImpl implements IPlayerVersion
{
    @Override
    public PlayerVersion getPlayerVersion(final Player player) {
        return PlayerVersion.getVersionFromRaw(ProtocolSupportAPI.getProtocolVersion(player).getId());
    }
}
