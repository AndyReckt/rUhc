package io.github.thatkawaiisam.utils.playerversion;

import org.bukkit.entity.*;

public interface IPlayerVersion
{
    PlayerVersion getPlayerVersion(final Player p0);
}
