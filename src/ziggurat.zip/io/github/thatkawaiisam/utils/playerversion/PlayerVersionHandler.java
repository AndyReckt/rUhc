package io.github.thatkawaiisam.utils.playerversion;

import org.bukkit.*;
import io.github.thatkawaiisam.utils.serverversion.*;
import io.github.thatkawaiisam.utils.playerversion.impl.*;
import org.bukkit.plugin.*;

public class PlayerVersionHandler
{
    public static IPlayerVersion version;
    
    public PlayerVersionHandler() {
        final PluginManager pluginManager = Bukkit.getServer().getPluginManager();
        if (ServerVersionHandler.serverVersionName.contains("1_7")) {
            PlayerVersionHandler.version = new PlayerVersion1_7Impl();
            return;
        }
        if (pluginManager.getPlugin("ProtocolSupport") != null || pluginManager.getPlugin("CuckSupport") != null) {
            PlayerVersionHandler.version = new PlayerVersionProtocolSupportImpl();
            return;
        }
        if (pluginManager.getPlugin("ViaVersion") != null) {
            PlayerVersionHandler.version = new PlayerVersionViaVersionImpl();
            return;
        }
        if (pluginManager.getPlugin("ProtocolLib") != null) {
            PlayerVersionHandler.version = new PlayerVersionProtocolLibImpl();
        }
    }
}
