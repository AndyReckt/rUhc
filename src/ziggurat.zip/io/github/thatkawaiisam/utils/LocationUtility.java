package io.github.thatkawaiisam.utils;

import org.bukkit.*;

public class LocationUtility
{
    public static String parseToString(final Location location) {
        return location.getX() + "," + location.getY() + "," + location.getZ() + "," + location.getYaw() + "," + location.getPitch() + "," + location.getWorld().getName();
    }
    
    public static Location parseToLocation(final String string) {
        if (string == null) {
            return null;
        }
        final String[] data = string.split(",");
        try {
            final double x = Double.parseDouble(data[0]);
            final double y = Double.parseDouble(data[1]);
            final double z = Double.parseDouble(data[2]);
            final float pitch = Float.valueOf(data[4]);
            final float yaw = Float.valueOf(data[3]);
            final World world = Bukkit.getWorld(data[5]);
            final Location location = new Location(world, x, y, z, yaw, pitch);
            return location;
        }
        catch (NumberFormatException ex) {
            ex.printStackTrace();
            return null;
        }
    }
}
