package io.github.thatkawaiisam.utils;

import org.bukkit.plugin.java.*;
import org.bukkit.entity.*;
import org.bukkit.plugin.*;
import com.google.common.io.*;

public class BungeeUtility
{
    public static void sendPlayerToServer(final JavaPlugin plugin, final Player player, final String server) {
        final ByteArrayDataOutput out = ByteStreams.newDataOutput();
        out.writeUTF("Connect");
        out.writeUTF(server);
        player.sendPluginMessage((Plugin)plugin, "BungeeCord", out.toByteArray());
    }
}
