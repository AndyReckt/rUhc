package io.github.thatkawaiisam.utils;

import org.bukkit.inventory.*;
import org.bukkit.entity.*;
import java.io.*;
import java.util.*;
import com.google.gson.*;

public class CachedInventory
{
    private ItemStack[] cachedInventory;
    private ItemStack[] cachedArmor;
    private double health;
    private int totalExperience;
    private int food;
    private float exp;
    
    public CachedInventory() {
        this.health = -1.0;
        this.totalExperience = -1;
        this.food = -1;
        this.exp = -1.0f;
    }
    
    public CachedInventory(final Player player, final boolean justContents) {
        this.health = -1.0;
        this.totalExperience = -1;
        this.food = -1;
        this.exp = -1.0f;
        this.cachedInventory = player.getInventory().getContents();
        this.cachedArmor = player.getInventory().getArmorContents();
        if (!justContents) {
            this.health = player.getHealth();
            this.food = player.getFoodLevel();
            this.totalExperience = player.getTotalExperience();
            this.exp = player.getExp();
        }
    }
    
    public static CachedInventory fromPlayer(final Player player, final boolean justContents) {
        return new CachedInventory(player, justContents);
    }
    
    public void applyToPlayer(final Player player, final boolean justContents) {
        player.getInventory().setContents(this.cachedInventory);
        player.getInventory().setArmorContents(this.cachedArmor);
        if (!justContents) {
            if (this.health != -1.0) {
                player.setHealth(this.health);
            }
            if (this.food != -1) {
                player.setFoodLevel(this.food);
            }
            if (this.totalExperience != -1) {
                player.setTotalExperience(this.totalExperience);
            }
            if (this.exp != -1.0f) {
                player.setExp(this.exp);
            }
        }
    }
    
    public static CachedInventory fromJson(final JsonObject jsonObject) {
        final CachedInventory cachedInventory = new CachedInventory();
        final JsonArray armorArray = jsonObject.get("armor").getAsJsonArray();
        final List<ItemStack> armor = new ArrayList<ItemStack>();
        final List<ItemStack> list = new ArrayList<>();
        armorArray.forEach(armorElement -> {
            try {
                list.add(ItemBuilder.itemFrom64(armorElement.getAsString()));
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            return;
        });
        cachedInventory.setCachedArmor(armor.stream().toArray(ItemStack[]::new));
        final JsonArray invArray = jsonObject.get("inv").getAsJsonArray();
        final List<ItemStack> inv = new ArrayList<ItemStack>();
        final List<ItemStack> list2 = new ArrayList<>();
        invArray.forEach(invElement -> {
            try {
                list2.add(ItemBuilder.itemFrom64(invElement.getAsString()));
            }
            catch (IOException e2) {
                e2.printStackTrace();
            }
            return;
        });
        cachedInventory.setCachedInventory(inv.stream().toArray(ItemStack[]::new));
        if (jsonObject.has("health")) {
            cachedInventory.setHealth(jsonObject.get("health").getAsDouble());
        }
        if (jsonObject.has("totalExperience")) {
            cachedInventory.setHealth(jsonObject.get("totalExperience").getAsInt());
        }
        if (jsonObject.has("food")) {
            cachedInventory.setHealth(jsonObject.get("food").getAsInt());
        }
        if (jsonObject.has("exp")) {
            cachedInventory.setHealth(jsonObject.get("exp").getAsFloat());
        }
        return cachedInventory;
    }
    
    public JsonObject toJson() {
        final JsonObject jsonObject = new JsonObject();
        if (this.health != -1.0) {
            jsonObject.addProperty("health", (Number)this.health);
        }
        if (this.totalExperience != -1) {
            jsonObject.addProperty("totalExperience", (Number)this.totalExperience);
        }
        if (this.food != -1) {
            jsonObject.addProperty("food", (Number)this.food);
        }
        if (this.exp != -1.0f) {
            jsonObject.addProperty("exp", (Number)this.exp);
        }
        final JsonArray armorArray = new JsonArray();
        for (final ItemStack itemStack : this.cachedArmor) {
            armorArray.add((JsonElement)new JsonPrimitive(ItemBuilder.itemTo64(itemStack)));
        }
        jsonObject.add("armor", (JsonElement)armorArray);
        final JsonArray invArray = new JsonArray();
        for (final ItemStack itemStack2 : this.cachedInventory) {
            invArray.add((JsonElement)new JsonPrimitive(ItemBuilder.itemTo64(itemStack2)));
        }
        jsonObject.add("inv", (JsonElement)invArray);
        return jsonObject;
    }
    
    public ItemStack[] getCachedInventory() {
        return this.cachedInventory;
    }
    
    public ItemStack[] getCachedArmor() {
        return this.cachedArmor;
    }
    
    public double getHealth() {
        return this.health;
    }
    
    public int getTotalExperience() {
        return this.totalExperience;
    }
    
    public int getFood() {
        return this.food;
    }
    
    public float getExp() {
        return this.exp;
    }
    
    public void setCachedInventory(final ItemStack[] cachedInventory) {
        this.cachedInventory = cachedInventory;
    }
    
    public void setCachedArmor(final ItemStack[] cachedArmor) {
        this.cachedArmor = cachedArmor;
    }
    
    public void setHealth(final double health) {
        this.health = health;
    }
    
    public void setTotalExperience(final int totalExperience) {
        this.totalExperience = totalExperience;
    }
    
    public void setFood(final int food) {
        this.food = food;
    }
    
    public void setExp(final float exp) {
        this.exp = exp;
    }
}
