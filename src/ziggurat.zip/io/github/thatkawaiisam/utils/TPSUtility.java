package io.github.thatkawaiisam.utils;

import java.lang.reflect.*;
import org.bukkit.*;

public class TPSUtility
{
    private static Object minecraftServer;
    private static Field recentTps;
    private static Boolean isPaperSpigot;
    
    public static double[] getRecentTps() {
        if (TPSUtility.isPaperSpigot == null) {
            try {
                final double[] recentTps = getRecentTpsPaperSpigot();
                TPSUtility.isPaperSpigot = true;
                return recentTps;
            }
            catch (Throwable t) {
                TPSUtility.isPaperSpigot = false;
            }
        }
        if (TPSUtility.isPaperSpigot) {
            try {
                return getRecentTpsPaperSpigot();
            }
            catch (Throwable throwable) {
                return new double[] { 20.0, 20.0, 20.0 };
            }
        }
        try {
            return getRecentTpsRefl();
        }
        catch (Throwable throwable) {
            return new double[] { 20.0, 20.0, 20.0 };
        }
    }
    
    private static double[] getRecentTpsPaperSpigot() {
        return Bukkit.getServer().spigot().getTPS();
    }
    
    private static double[] getRecentTpsRefl() throws Throwable {
        if (TPSUtility.minecraftServer == null) {
            final Server server = Bukkit.getServer();
            final Field consoleField = server.getClass().getDeclaredField("console");
            consoleField.setAccessible(true);
            TPSUtility.minecraftServer = consoleField.get(server);
        }
        if (TPSUtility.recentTps == null) {
            (TPSUtility.recentTps = TPSUtility.minecraftServer.getClass().getSuperclass().getDeclaredField("recentTps")).setAccessible(true);
        }
        return (double[])TPSUtility.recentTps.get(TPSUtility.minecraftServer);
    }
    
    static {
        TPSUtility.isPaperSpigot = null;
    }
}
