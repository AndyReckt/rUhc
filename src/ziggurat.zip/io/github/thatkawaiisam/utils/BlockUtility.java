package io.github.thatkawaiisam.utils;

import org.bukkit.block.*;
import java.util.*;
import java.util.stream.*;
import org.bukkit.*;

public class BlockUtility
{
    public static boolean isMaterialWithinBlock(final Material material, final Block block) {
        final Location location = block.getLocation();
        final World world = location.getWorld();
        final int x = location.getBlockX();
        final int y = location.getBlockY();
        final int z = location.getBlockZ();
        final Set<Material> blocks = Stream.of(new Material[] { world.getBlockAt(new Location(world, (double)x, (double)(y + 1), (double)z)).getType(), world.getBlockAt(new Location(world, (double)x, (double)(y - 1), (double)z)).getType(), world.getBlockAt(new Location(world, (double)(x + 1), (double)y, (double)z)).getType(), world.getBlockAt(new Location(world, (double)(x - 1), (double)y, (double)z)).getType(), world.getBlockAt(new Location(world, (double)x, (double)y, (double)(z + 1))).getType(), world.getBlockAt(new Location(world, (double)x, (double)y, (double)(z - 1))).getType() }).collect(Collectors.toSet());
        return blocks.contains(material);
    }
}
