package io.github.thatkawaiisam.utils;

import io.github.thatkawaiisam.utils.serverversion.*;
import io.github.thatkawaiisam.utils.playerversion.*;

public class UtilityManager
{
    private static boolean initiated;
    
    public static void init() {
        if (UtilityManager.initiated) {
            return;
        }
        new ServerVersionHandler();
        new PlayerVersionHandler();
        UtilityManager.initiated = true;
    }
    
    static {
        UtilityManager.initiated = false;
    }
}
