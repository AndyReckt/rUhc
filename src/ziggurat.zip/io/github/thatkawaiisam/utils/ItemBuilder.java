package io.github.thatkawaiisam.utils;

import org.bukkit.*;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.*;
import java.util.*;
import org.bukkit.inventory.meta.*;
import org.yaml.snakeyaml.external.biz.base64Coder.*;
import org.bukkit.util.io.*;
import java.io.*;

public class ItemBuilder
{
    private Material material;
    private Short durability;
    private String title;
    private int amount;
    private List<String> lores;
    private byte materialData;
    private HashMap<Enchantment, Integer> enchantments;
    private ItemStack itemStack;
    
    public ItemBuilder() {
        this.amount = 1;
        this.enchantments = new HashMap<Enchantment, Integer>();
        this.itemStack = new ItemStack(Material.AIR);
    }
    
    public ItemBuilder(final Material material) {
        this.amount = 1;
        this.enchantments = new HashMap<Enchantment, Integer>();
        this.itemStack = new ItemStack(material);
    }
    
    public ItemBuilder(final ItemStack itemStack) {
        this.amount = 1;
        this.enchantments = new HashMap<Enchantment, Integer>();
        this.itemStack = itemStack;
    }
    
    public ItemBuilder material(final Material material) {
        this.material = material;
        return this;
    }
    
    public ItemBuilder durability(final short durability) {
        this.durability = durability;
        return this;
    }
    
    public ItemBuilder title(final String title) {
        this.title = title;
        return this;
    }
    
    public ItemBuilder amount(final int amount) {
        this.amount = amount;
        return this;
    }
    
    public ItemBuilder lores(final List<String> lores) {
        this.lores = lores;
        return this;
    }
    
    public ItemBuilder enchantment(final Enchantment enchantment, final int level) {
        this.enchantments.put(enchantment, level);
        return this;
    }
    
    public ItemBuilder enchantment(final Enchantment enchantment) {
        this.enchantment(enchantment, 1);
        return this;
    }
    
    public ItemBuilder clearLore() {
        this.lores.clear();
        return this;
    }
    
    public ItemBuilder data(final int data) {
        this.materialData = (byte)data;
        return this;
    }
    
    public ItemBuilder clearEnchantments() {
        this.enchantments.clear();
        return this;
    }
    
    public ItemStack build() {
        final ItemStack itemStack = this.itemStack;
        if (this.material != null) {
            itemStack.setType(this.material);
        }
        for (final Enchantment enchantment : this.enchantments.keySet()) {
            itemStack.addUnsafeEnchantment(enchantment, (int)this.enchantments.get(enchantment));
        }
        final ItemMeta meta = itemStack.getItemMeta();
        if (this.amount > 0) {
            itemStack.setAmount(this.amount);
        }
        if (this.durability != null) {
            itemStack.setDurability((short)this.durability);
        }
        if (this.title != null) {
            meta.setDisplayName(MessageUtility.formatMessage("&r" + this.title));
        }
        if (this.lores != null && this.lores.size() > 0) {
            meta.setLore((List)MessageUtility.formatMessages(this.lores));
        }
        itemStack.setItemMeta(meta);
        return itemStack;
    }
    
    public static String itemTo64(final ItemStack stack) throws IllegalStateException {
        try {
            final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            final BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream((OutputStream)outputStream);
            dataOutput.writeObject((Object)stack);
            dataOutput.close();
            return Base64Coder.encodeLines(outputStream.toByteArray());
        }
        catch (Exception e) {
            throw new IllegalStateException("Unable to save item stack.", e);
        }
    }
    
    public static ItemStack itemFrom64(final String data) throws IOException {
        try {
            final ByteArrayInputStream inputStream = new ByteArrayInputStream(Base64Coder.decodeLines(data));
            final BukkitObjectInputStream dataInput = new BukkitObjectInputStream((InputStream)inputStream);
            try {
                return (ItemStack)dataInput.readObject();
            }
            finally {
                dataInput.close();
            }
        }
        catch (ClassNotFoundException e) {
            throw new IOException("Unable to decode class type.", e);
        }
    }
}
