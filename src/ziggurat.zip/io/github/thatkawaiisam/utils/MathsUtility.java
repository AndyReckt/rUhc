package io.github.thatkawaiisam.utils;

public class MathsUtility
{
    public static Boolean isBetween(final Integer input, final Integer min, final Integer max) {
        return input >= min && input <= max;
    }
    
    public static int convertToPositive(final int input) {
        if (input > 0) {
            return input;
        }
        return Math.abs(input);
    }
    
    public static String getCorrectPronumeral(final String text, final int input) {
        return text + ((input == 1) ? "" : "s");
    }
}
