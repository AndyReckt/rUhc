package io.github.thatkawaiisam.utils;

import org.bukkit.*;
import java.util.*;

public class MessageUtility
{
    public static String formatMessage(final String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    public static List<String> formatMessages(final List<String> messages) {
        final List<String> buffered = new ArrayList<String>();
        for (final String message : messages) {
            buffered.add(formatMessage("&r" + message));
        }
        return buffered;
    }
    
    public static String capitalizeFirstLetter(final String original) {
        if (original == null || original.length() == 0) {
            return original;
        }
        return original.substring(0, 1).toUpperCase() + original.substring(1);
    }
}
