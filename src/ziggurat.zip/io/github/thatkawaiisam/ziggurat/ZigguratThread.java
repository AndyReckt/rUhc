package io.github.thatkawaiisam.ziggurat;

public class ZigguratThread extends Thread
{
    private Ziggurat ziggurat;
    
    public ZigguratThread(final Ziggurat ziggurat) {
        this.ziggurat = ziggurat;
        this.start();
    }
    
    @Override
    public void run() {
        while (true) {
            try {
                this.ziggurat.getTablists().values().forEach(ZigguratTablist::update);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            try {
                Thread.sleep(this.ziggurat.getTicks() * 50L);
            }
            catch (InterruptedException e2) {
                e2.printStackTrace();
            }
        }
    }
}
