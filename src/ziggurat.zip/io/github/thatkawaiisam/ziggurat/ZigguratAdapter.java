package io.github.thatkawaiisam.ziggurat;

import org.bukkit.entity.*;
import java.util.*;
import io.github.thatkawaiisam.ziggurat.utils.*;

public interface ZigguratAdapter
{
    Set<BufferedTabObject> getSlots(final Player p0);
    
    String getFooter();
    
    String getHeader();
}
