package io.github.thatkawaiisam.ziggurat.utils.impl;

import net.minecraft.server.v1_7_R4.Packet;
import net.minecraft.server.v1_7_R4.PacketPlayOutPlayerInfo;
import org.bukkit.entity.*;
import io.github.thatkawaiisam.ziggurat.*;
import org.bukkit.*;
import org.bukkit.scoreboard.*;
import org.spigotmc.ProtocolInjector;
import org.spigotmc.ProtocolInjector.PacketTabHeader;
import io.github.thatkawaiisam.ziggurat.utils.*;
import java.util.*;


public class v1_7TabImpl implements IZigguratHelper
{
    private static final net.minecraft.server.v1_7_R4.MinecraftServer server;
    private static final net.minecraft.server.v1_7_R4.WorldServer world;
    private static final net.minecraft.server.v1_7_R4.PlayerInteractManager manager;
    
    @Override
    public void recreatePlayer(final ZigguratTablist tablist, final Player player) {
    }
    
    @Override
    public TabEntry createFakePlayer(final ZigguratTablist zigguratTablist, final String string, final TabColumn column, final Integer slot, final Integer rawSlot) {
        final UUID uuid = UUID.randomUUID();
        final net.minecraft.util.com.mojang.authlib.GameProfile profile = new net.minecraft.util.com.mojang.authlib.GameProfile(uuid, LegacyClientUtils.tabEntrys.get(rawSlot - 1) + "");
        final net.minecraft.server.v1_7_R4.EntityPlayer entity = new net.minecraft.server.v1_7_R4.EntityPlayer(v1_7TabImpl.server, v1_7TabImpl.world, profile, v1_7TabImpl.manager);
        profile.getProperties().put("textures", new net.minecraft.util.com.mojang.authlib.properties.Property("textures", ZigguratCommons.defaultTexture.SKIN_VALUE, ZigguratCommons.defaultTexture.SKIN_SIGNATURE));
        entity.ping = 1;
        final Packet packet = (Packet) PacketPlayOutPlayerInfo.addPlayer(entity);
        this.sendPacket(zigguratTablist.getPlayer(), packet);
        return new TabEntry(string, uuid, "", zigguratTablist, ZigguratCommons.defaultTexture, column, slot, rawSlot, 1);
    }
    
    @Override
    public void destoryFakePlayer(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final String customName) {
        String name;
        if (customName != null) {
            name = customName;
        }
        else {
            name = LegacyClientUtils.tabEntrys.get(tabEntry.getRawSlot() - 1) + "";
        }
        final net.minecraft.util.com.mojang.authlib.GameProfile profile = new net.minecraft.util.com.mojang.authlib.GameProfile(tabEntry.getUuid(), name);
        final net.minecraft.server.v1_7_R4.EntityPlayer entity = new net.minecraft.server.v1_7_R4.EntityPlayer(v1_7TabImpl.server, v1_7TabImpl.world, profile, v1_7TabImpl.manager);
        final Packet packet = (Packet)PacketPlayOutPlayerInfo.removePlayer(entity);
        this.sendPacket(zigguratTablist.getPlayer(), packet);
    }
    
    @Override
    public void updateFakeName(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final String text) {
        final Player player = zigguratTablist.getPlayer();
        final String[] newStrings = ZigguratTablist.splitStrings(text);
        Team team = player.getScoreboard().getTeam((String)LegacyClientUtils.teamNames.get(tabEntry.getRawSlot() - 1));
        if (team == null) {
            team = player.getScoreboard().registerNewTeam((String)LegacyClientUtils.teamNames.get(tabEntry.getRawSlot() - 1));
        }
        team.setPrefix(ChatColor.translateAlternateColorCodes('&', newStrings[0]));
        if (newStrings.length > 1) {
            team.setSuffix(ChatColor.translateAlternateColorCodes('&', newStrings[1]));
        }
        else {
            team.setSuffix("");
        }
        tabEntry.setText(text);
    }
    
    @Override
    public void updateFakeLatency(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final Integer latency) {
        final net.minecraft.util.com.mojang.authlib.GameProfile profile = new net.minecraft.util.com.mojang.authlib.GameProfile(tabEntry.getUuid(), LegacyClientUtils.tabEntrys.get(tabEntry.getRawSlot() - 1) + "");
        final net.minecraft.server.v1_7_R4.EntityPlayer entity = new net.minecraft.server.v1_7_R4.EntityPlayer(v1_7TabImpl.server, v1_7TabImpl.world, profile, v1_7TabImpl.manager);
        entity.ping = latency;
        final Packet packet = (Packet)PacketPlayOutPlayerInfo.updatePing(entity);
        this.sendPacket(zigguratTablist.getPlayer(), packet);
        tabEntry.setLatency(latency);
    }
    
    @Override
    public void updateFakeSkin(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final SkinTexture skinTexture) {
        final net.minecraft.util.com.mojang.authlib.GameProfile profile = new net.minecraft.util.com.mojang.authlib.GameProfile(tabEntry.getUuid(), LegacyClientUtils.tabEntrys.get(tabEntry.getRawSlot() - 1) + "");
        final net.minecraft.server.v1_7_R4.EntityPlayer entity = new net.minecraft.server.v1_7_R4.EntityPlayer(v1_7TabImpl.server, v1_7TabImpl.world, profile, v1_7TabImpl.manager);
        profile.getProperties().put("textures", new net.minecraft.util.com.mojang.authlib.properties.Property("textures", skinTexture.SKIN_VALUE, skinTexture.SKIN_SIGNATURE));
        final Packet removePlayer = (Packet)PacketPlayOutPlayerInfo.removePlayer(entity);
        this.sendPacket(zigguratTablist.getPlayer(), removePlayer);
        final Packet addPlayer = (Packet)PacketPlayOutPlayerInfo.addPlayer(entity);
        this.sendPacket(zigguratTablist.getPlayer(), addPlayer);
        tabEntry.setTexture(skinTexture);
    }

    @Override
    public void updateHeaderAndFooter(final ZigguratTablist zigguratTablist, final String header, final String footer) {
        final net.minecraft.server.v1_7_R4.IChatBaseComponent tabTitle = net.minecraft.server.v1_7_R4.ChatSerializer.a("{text: '" + header + "'}");
        final net.minecraft.server.v1_7_R4.IChatBaseComponent tabFoot = net.minecraft.server.v1_7_R4.ChatSerializer.a("{text: '" + footer + "'}");
        final ProtocolInjector.PacketTabHeader packetTabHeader = new ProtocolInjector.PacketTabHeader(tabTitle, tabFoot);
        this.sendPacket(zigguratTablist.getPlayer(), (Packet)packetTabHeader);
    }
    
    @Override
    public SkinTexture getTexture(final Player player) {
        final net.minecraft.server.v1_7_R4.EntityPlayer entityPlayer = ((org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer)player).getHandle();
        final Collection<net.minecraft.util.com.mojang.authlib.properties.Property> properties = (Collection<net.minecraft.util.com.mojang.authlib.properties.Property>)entityPlayer.getProfile().getProperties().get("textures");
        if (properties != null && properties.size() > 0) {
            final net.minecraft.util.com.mojang.authlib.properties.Property actual = properties.iterator().next();
            return new SkinTexture(actual.getValue(), actual.getSignature());
        }
        return ZigguratCommons.defaultTexture;
    }
    
    private void sendPacket(final Player player, final Packet packet) {
        this.getEntity(player).playerConnection.sendPacket(packet);
    }
    
    private net.minecraft.server.v1_7_R4.EntityPlayer getEntity(final Player player) {
        return ((org.bukkit.craftbukkit.v1_7_R4.entity.CraftPlayer)player).getHandle();
    }

    static {
        server = net.minecraft.server.v1_7_R4.MinecraftServer.getServer();
        world = v1_7TabImpl.server.getWorldServer(0);
        manager = new net.minecraft.server.v1_7_R4.PlayerInteractManager(v1_7TabImpl.world);
    }
}
