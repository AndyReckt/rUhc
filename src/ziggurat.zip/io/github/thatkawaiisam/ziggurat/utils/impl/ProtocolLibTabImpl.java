package io.github.thatkawaiisam.ziggurat.utils.impl;

import org.bukkit.entity.*;
import com.comphenix.protocol.*;
import com.comphenix.protocol.events.*;
import io.github.thatkawaiisam.utils.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import io.github.thatkawaiisam.ziggurat.*;
import com.comphenix.protocol.wrappers.*;
import org.bukkit.*;
import org.bukkit.scoreboard.*;
import io.github.thatkawaiisam.ziggurat.utils.*;
import java.util.*;
import java.lang.reflect.*;

public class ProtocolLibTabImpl implements IZigguratHelper
{
    @Override
    public void recreatePlayer(final ZigguratTablist tablist, final Player player) {
        final PacketContainer packet = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
        packet.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.ADD_PLAYER);
        final WrappedGameProfile profile = WrappedGameProfile.fromPlayer(player);
        final PlayerInfoData playerInfoData = new PlayerInfoData(profile, PingUtility.getPing(player), EnumWrappers.NativeGameMode.fromBukkit(player.getGameMode()), WrappedChatComponent.fromText(player.getName()));
        packet.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
        sendPacket(tablist.getPlayer(), packet);
    }
    
    @Override
    public TabEntry createFakePlayer(final ZigguratTablist zigguratTablist, final String string, final TabColumn column, final Integer slot, final Integer rawSlot) {
        final UUID uuid = UUID.randomUUID();
        final Player player = zigguratTablist.getPlayer();
        final PlayerVersion playerVersion = PlayerUtility.getPlayerVersion(player);
        final PacketContainer packet = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
        packet.getPlayerInfoAction().write(0, (EnumWrappers.PlayerInfoAction) EnumWrappers.PlayerInfoAction.ADD_PLAYER);
        final WrappedGameProfile profile = new WrappedGameProfile(uuid, (playerVersion != PlayerVersion.v1_7) ? string : (LegacyClientUtils.tabEntrys.get(rawSlot - 1) + ""));
        final PlayerInfoData playerInfoData = new PlayerInfoData(profile, 1, EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText((playerVersion != PlayerVersion.v1_7) ? "" : profile.getName()));
        if (playerVersion != PlayerVersion.v1_7) {
            playerInfoData.getProfile().getProperties().put("textures",new WrappedSignedProperty("textures", ZigguratCommons.defaultTexture.SKIN_VALUE, ZigguratCommons.defaultTexture.SKIN_SIGNATURE));
        }
        packet.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
        sendPacket(player, packet);
        return new TabEntry(string, uuid, "", zigguratTablist, ZigguratCommons.defaultTexture, column, slot, rawSlot, 1);
    }
    
    @Override
    public void destoryFakePlayer(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final String customName) {
        final Player player = zigguratTablist.getPlayer();
        final PlayerVersion playerVersion = PlayerUtility.getPlayerVersion(player);
        final PacketContainer packet = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
        packet.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.REMOVE_PLAYER);
        final WrappedGameProfile profile = new WrappedGameProfile(tabEntry.getUuid(), (playerVersion != PlayerVersion.v1_7) ? tabEntry.getId() : (LegacyClientUtils.tabEntrys.get(tabEntry.getRawSlot() - 1) + ""));
        final PlayerInfoData playerInfoData = new PlayerInfoData(profile, 1, EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText((playerVersion != PlayerVersion.v1_7) ? "" : profile.getName()));
        packet.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
        sendPacket(player, packet);
    }
    
    @Override
    public void updateFakeName(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final String text) {
        final Player player = zigguratTablist.getPlayer();
        final PlayerVersion playerVersion = PlayerUtility.getPlayerVersion(player);
        final String[] newStrings = ZigguratTablist.splitStrings(text);
        if (playerVersion == PlayerVersion.v1_7) {
            Team team = player.getScoreboard().getTeam((String)LegacyClientUtils.teamNames.get(tabEntry.getRawSlot() - 1));
            if (team == null) {
                team = player.getScoreboard().registerNewTeam((String)LegacyClientUtils.teamNames.get(tabEntry.getRawSlot() - 1));
                team.addEntry((String)LegacyClientUtils.tabEntrys.get(tabEntry.getRawSlot() - 1));
            }
            team.setPrefix(ChatColor.translateAlternateColorCodes('&', newStrings[0]));
            if (newStrings.length > 1) {
                team.setSuffix(ChatColor.translateAlternateColorCodes('&', newStrings[1]));
            }
            else {
                team.setSuffix("");
            }
        }
        else {
            final PacketContainer packet = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
            packet.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.UPDATE_DISPLAY_NAME);
            final WrappedGameProfile profile = new WrappedGameProfile(tabEntry.getUuid(), tabEntry.getId());
            final PlayerInfoData playerInfoData = new PlayerInfoData(profile, 1, EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText(ChatColor.translateAlternateColorCodes('&', (newStrings.length > 1) ? (newStrings[0] + newStrings[1]) : newStrings[0])));
            packet.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
            sendPacket(player, packet);
        }
        tabEntry.setText(text);
    }
    
    @Override
    public void updateFakeLatency(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final Integer latency) {
        final PacketContainer packet = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
        packet.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.UPDATE_LATENCY);
        final WrappedGameProfile profile = new WrappedGameProfile(tabEntry.getUuid(), tabEntry.getId());
        final PlayerInfoData playerInfoData = new PlayerInfoData(profile, (int)latency, EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText(ChatColor.translateAlternateColorCodes('&', tabEntry.getText())));
        packet.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
        sendPacket(zigguratTablist.getPlayer(), packet);
        tabEntry.setLatency(latency);
    }
    
    @Override
    public void updateFakeSkin(final ZigguratTablist zigguratTablist, final TabEntry tabEntry, final SkinTexture skinTexture) {
        final Player player = zigguratTablist.getPlayer();
        final PlayerVersion playerVersion = PlayerUtility.getPlayerVersion(player);
        final WrappedGameProfile profile = new WrappedGameProfile(tabEntry.getUuid(), (playerVersion != PlayerVersion.v1_7) ? tabEntry.getId() : (LegacyClientUtils.tabEntrys.get(tabEntry.getRawSlot() - 1) + ""));
        final PlayerInfoData playerInfoData = new PlayerInfoData(profile, 1, EnumWrappers.NativeGameMode.SURVIVAL, WrappedChatComponent.fromText((playerVersion != PlayerVersion.v1_7) ? "" : profile.getName()));
        playerInfoData.getProfile().getProperties().put("texture", new WrappedSignedProperty("textures", skinTexture.SKIN_VALUE, skinTexture.SKIN_SIGNATURE));
        final PacketContainer remove = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
        remove.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.REMOVE_PLAYER);
        remove.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
        final PacketContainer add = ProtocolLibrary.getProtocolManager().createPacket(PacketType.Play.Server.PLAYER_INFO);
        add.getPlayerInfoAction().write(0, EnumWrappers.PlayerInfoAction.ADD_PLAYER);
        add.getPlayerInfoDataLists().write(0, Collections.singletonList(playerInfoData));
        sendPacket(player, remove);
        sendPacket(player, add);
        tabEntry.setTexture(skinTexture);
    }
    
    @Override
    public void updateHeaderAndFooter(final ZigguratTablist zigguratTablist, final String header, final String footer) {
        final Player player = zigguratTablist.getPlayer();
        final PacketContainer headerAndFooter = new PacketContainer(PacketType.Play.Server.PLAYER_LIST_HEADER_FOOTER);
        headerAndFooter.getChatComponents().write(0, WrappedChatComponent.fromText(header));
        headerAndFooter.getChatComponents().write(1, WrappedChatComponent.fromText(footer));
        sendPacket(player, headerAndFooter);
    }
    
    @Override
    public SkinTexture getTexture(final Player player) {
        final WrappedGameProfile profile = WrappedGameProfile.fromPlayer(player);
        final Collection<WrappedSignedProperty> property = (Collection<WrappedSignedProperty>)profile.getProperties().get("textures");
        if (property != null && property.size() > 0) {
            final WrappedSignedProperty actual = property.iterator().next();
            return new SkinTexture(actual.getValue(), actual.getSignature());
        }
        return ZigguratCommons.defaultTexture;
    }
    
    private static void sendPacket(final Player player, final PacketContainer packetContainer) {
        try {
            ProtocolLibrary.getProtocolManager().sendServerPacket(player, packetContainer);
        }
        catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
