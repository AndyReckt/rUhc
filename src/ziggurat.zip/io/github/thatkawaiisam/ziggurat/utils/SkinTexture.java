package io.github.thatkawaiisam.ziggurat.utils;

public class SkinTexture
{
    public String SKIN_VALUE;
    public String SKIN_SIGNATURE;
    
    public SkinTexture(final String skinValue, final String skinSig) {
        this.SKIN_VALUE = skinValue;
        this.SKIN_SIGNATURE = skinSig;
    }
    
    @Override
    public String toString() {
        return this.SKIN_SIGNATURE + this.SKIN_VALUE;
    }
    
    public void setSKIN_VALUE(final String SKIN_VALUE) {
        this.SKIN_VALUE = SKIN_VALUE;
    }
    
    public void setSKIN_SIGNATURE(final String SKIN_SIGNATURE) {
        this.SKIN_SIGNATURE = SKIN_SIGNATURE;
    }
}
