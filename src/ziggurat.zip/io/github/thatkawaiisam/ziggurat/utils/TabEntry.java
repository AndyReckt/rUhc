package io.github.thatkawaiisam.ziggurat.utils;

import java.util.*;
import io.github.thatkawaiisam.ziggurat.*;
import java.beans.*;

public class TabEntry
{
    private String id;
    private UUID uuid;
    private String text;
    private ZigguratTablist tab;
    private SkinTexture texture;
    private TabColumn column;
    private int slot;
    private int rawSlot;
    private int latency;
    
    public String getId() {
        return this.id;
    }
    
    public UUID getUuid() {
        return this.uuid;
    }
    
    public String getText() {
        return this.text;
    }
    
    public ZigguratTablist getTab() {
        return this.tab;
    }
    
    public SkinTexture getTexture() {
        return this.texture;
    }
    
    public TabColumn getColumn() {
        return this.column;
    }
    
    public int getSlot() {
        return this.slot;
    }
    
    public int getRawSlot() {
        return this.rawSlot;
    }
    
    public int getLatency() {
        return this.latency;
    }
    
    public void setId(final String id) {
        this.id = id;
    }
    
    public void setUuid(final UUID uuid) {
        this.uuid = uuid;
    }
    
    public void setText(final String text) {
        this.text = text;
    }
    
    public void setTab(final ZigguratTablist tab) {
        this.tab = tab;
    }
    
    public void setTexture(final SkinTexture texture) {
        this.texture = texture;
    }
    
    public void setColumn(final TabColumn column) {
        this.column = column;
    }
    
    public void setSlot(final int slot) {
        this.slot = slot;
    }
    
    public void setRawSlot(final int rawSlot) {
        this.rawSlot = rawSlot;
    }
    
    public void setLatency(final int latency) {
        this.latency = latency;
    }
    
    @ConstructorProperties({ "id", "uuid", "text", "tab", "texture", "column", "slot", "rawSlot", "latency" })
    public TabEntry(final String id, final UUID uuid, final String text, final ZigguratTablist tab, final SkinTexture texture, final TabColumn column, final int slot, final int rawSlot, final int latency) {
        this.id = id;
        this.uuid = uuid;
        this.text = text;
        this.tab = tab;
        this.texture = texture;
        this.column = column;
        this.slot = slot;
        this.rawSlot = rawSlot;
        this.latency = latency;
    }
}
