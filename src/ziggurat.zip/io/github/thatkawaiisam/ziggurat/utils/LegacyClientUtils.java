package io.github.thatkawaiisam.ziggurat.utils;

import java.util.*;
import org.bukkit.*;

public class LegacyClientUtils
{
    public static ArrayList<String> tabEntrys;
    public static ArrayList<String> teamNames;
    
    private static ArrayList<String> getTabEntrys() {
        final ArrayList<String> list = new ArrayList<String>();
        for (int i = 1; i <= 15; ++i) {
            final String entry = ChatColor.values()[i].toString();
            list.add(ChatColor.RED + entry);
            list.add(ChatColor.GREEN + entry);
            list.add(ChatColor.DARK_RED + entry);
            list.add(ChatColor.DARK_GREEN + entry);
            list.add(ChatColor.BLUE + entry);
            list.add(ChatColor.DARK_BLUE + entry);
        }
        return list;
    }
    
    private static ArrayList<String> getTeamNames() {
        final ArrayList<String> list = new ArrayList<String>();
        for (int i = 0; i < 80; ++i) {
            final String s = ((i < 10) ? "\\u00010" : "\\u0001") + i;
            list.add(s);
        }
        return list;
    }
    
    static {
        LegacyClientUtils.tabEntrys = getTabEntrys();
        LegacyClientUtils.teamNames = getTeamNames();
    }
}
