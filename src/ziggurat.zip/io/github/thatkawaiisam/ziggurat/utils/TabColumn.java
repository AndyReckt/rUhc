package io.github.thatkawaiisam.ziggurat.utils;

import org.bukkit.entity.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import io.github.thatkawaiisam.utils.*;
import java.util.*;

public enum TabColumn
{
    LEFT(0, "Left", -2, 1, 3), 
    MIDDLE(1, "Middle", -1, 21, 3), 
    RIGHT(2, "Right", 0, 41, 3), 
    FAR_RIGHT(3, "Far-Right", 60, 61, 1);
    
    private int startNumber;
    private int incrementBy;
    private int rawStart;
    private List<Integer> numbers;
    private String identifier;
    private int ordinal;
    private static TabColumn[] cachedValues;
    
    private TabColumn(final int ordinal, final String identifier, final int rawStart, final int startNumber, final int incrementBy) {
        this.numbers = new ArrayList<Integer>();
        this.ordinal = ordinal;
        this.identifier = identifier;
        this.rawStart = rawStart;
        this.startNumber = startNumber;
        this.incrementBy = incrementBy;
        this.generate();
    }
    
    public static TabColumn getColumn(final String identifier) {
        for (final TabColumn tabColumn : TabColumn.cachedValues) {
            if (tabColumn.getIdentifier().equalsIgnoreCase(identifier)) {
                return tabColumn;
            }
        }
        return null;
    }
    
    private void generate() {
        for (int i = 1; i <= 20; ++i) {
            final Integer numb = this.rawStart + i * this.incrementBy;
            this.numbers.add(numb);
        }
    }
    
    public static TabColumn getFromSlot(final Player player, final Integer slot) {
        if (PlayerUtility.getPlayerVersion(player) == PlayerVersion.v1_7) {
            return Arrays.stream(TabColumn.cachedValues).filter(tabColumn -> tabColumn.getNumbers().contains(slot)).findFirst().get();
        }
        if (MathsUtility.isBetween(slot, Integer.valueOf(1), Integer.valueOf(20))) {
            return TabColumn.LEFT;
        }
        if (MathsUtility.isBetween(slot, Integer.valueOf(21), Integer.valueOf(40))) {
            return TabColumn.MIDDLE;
        }
        if (MathsUtility.isBetween(slot, Integer.valueOf(41), Integer.valueOf(60))) {
            return TabColumn.RIGHT;
        }
        if (MathsUtility.isBetween(slot, Integer.valueOf(61), Integer.valueOf(80))) {
            return TabColumn.FAR_RIGHT;
        }
        return null;
    }
    
    public Integer getNumb(final Player player, final int raw) {
        if (PlayerUtility.getPlayerVersion(player) != PlayerVersion.v1_7) {
            return raw - this.startNumber + 1;
        }
        int number = 0;
        for (final int integer : this.numbers) {
            ++number;
            if (integer == raw) {
                return number;
            }
        }
        return number;
    }
    
    public static TabColumn getFromOrdinal(final int ordinal) {
        for (final TabColumn column : TabColumn.cachedValues) {
            if (column.getOrdinal() == ordinal) {
                return column;
            }
        }
        return null;
    }
    
    public int getStartNumber() {
        return this.startNumber;
    }
    
    public int getIncrementBy() {
        return this.incrementBy;
    }
    
    public int getRawStart() {
        return this.rawStart;
    }
    
    public List<Integer> getNumbers() {
        return this.numbers;
    }
    
    public String getIdentifier() {
        return this.identifier;
    }
    
    public int getOrdinal() {
        return this.ordinal;
    }
    
    static {
        TabColumn.cachedValues = values();
    }
}
