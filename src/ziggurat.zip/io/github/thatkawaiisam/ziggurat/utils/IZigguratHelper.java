package io.github.thatkawaiisam.ziggurat.utils;

import io.github.thatkawaiisam.ziggurat.*;
import org.bukkit.entity.*;

public interface IZigguratHelper
{
    TabEntry createFakePlayer(final ZigguratTablist p0, final String p1, final TabColumn p2, final Integer p3, final Integer p4);
    
    void recreatePlayer(final ZigguratTablist p0, final Player p1);
    
    void updateFakeName(final ZigguratTablist p0, final TabEntry p1, final String p2);
    
    void updateFakeLatency(final ZigguratTablist p0, final TabEntry p1, final Integer p2);
    
    void updateFakeSkin(final ZigguratTablist p0, final TabEntry p1, final SkinTexture p2);
    
    void updateHeaderAndFooter(final ZigguratTablist p0, final String p1, final String p2);
    
    void destoryFakePlayer(final ZigguratTablist p0, final TabEntry p1, final String p2);
    
    SkinTexture getTexture(final Player p0);
}
