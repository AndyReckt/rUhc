package io.github.thatkawaiisam.ziggurat.utils.ping;

import org.bukkit.entity.*;

public interface IPingProvider
{
    int getDefaultPing(final Player p0);
}
