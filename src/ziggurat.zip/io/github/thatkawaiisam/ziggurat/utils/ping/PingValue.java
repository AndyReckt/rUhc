package io.github.thatkawaiisam.ziggurat.utils.ping;

public enum PingValue
{
    NO_CONNECTION(-1), 
    ONE_BAR(1000), 
    TWO_BARS(999), 
    THREE_BARS(599), 
    FOUR_BARS(299), 
    FULL_BARS(149);
    
    private int value;
    
    private PingValue(final int value) {
        this.value = value;
    }
    
    public int getValue() {
        return this.value;
    }
}
