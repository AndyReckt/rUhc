package io.github.thatkawaiisam.ziggurat.utils.ping.impl;

import com.lunarclient.bukkitapi.LunarClientAPI;
import io.github.thatkawaiisam.ziggurat.utils.ping.*;
import org.bukkit.entity.*;


public class LunarPingImpl implements IPingProvider
{
    @Override
    public int getDefaultPing(final Player player) {
        if (LunarClientAPI.getInstance().isRunningLunarClient(player)) {
            return -1;
        }
        return 0;
    }
}
