package io.github.thatkawaiisam.ziggurat.utils.ping.impl;

import io.github.thatkawaiisam.ziggurat.utils.ping.*;
import org.bukkit.entity.*;

public class DefaultPingImpl implements IPingProvider
{
    @Override
    public int getDefaultPing(final Player player) {
        return 0;
    }
}
