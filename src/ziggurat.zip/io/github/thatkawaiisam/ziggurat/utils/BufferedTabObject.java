package io.github.thatkawaiisam.ziggurat.utils;

import io.github.thatkawaiisam.ziggurat.*;
import io.github.thatkawaiisam.ziggurat.utils.ping.*;

public class BufferedTabObject
{
    private TabColumn column;
    private Integer ping;
    private int slot;
    private String text;
    private SkinTexture skinTexture;
    
    public BufferedTabObject() {
        this.column = TabColumn.LEFT;
        this.slot = 1;
        this.text = "";
        this.skinTexture = ZigguratCommons.defaultTexture;
    }
    
    public BufferedTabObject text(final String text) {
        this.text = text;
        return this;
    }
    
    public BufferedTabObject skin(final SkinTexture skinTexture) {
        this.skinTexture = skinTexture;
        return this;
    }
    
    public BufferedTabObject slot(final Integer slot) {
        this.slot = slot;
        return this;
    }
    
    public BufferedTabObject ping(final Integer ping) {
        this.ping = ping;
        return this;
    }
    
    public BufferedTabObject ping(final PingValue ping) {
        this.ping = ping.getValue();
        return this;
    }
    
    public BufferedTabObject column(final TabColumn tabColumn) {
        this.column = tabColumn;
        return this;
    }
    
    public TabColumn getColumn() {
        return this.column;
    }
    
    public Integer getPing() {
        return this.ping;
    }
    
    public int getSlot() {
        return this.slot;
    }
    
    public String getText() {
        return this.text;
    }
    
    public SkinTexture getSkinTexture() {
        return this.skinTexture;
    }
    
    public void setColumn(final TabColumn column) {
        this.column = column;
    }
    
    public void setPing(final Integer ping) {
        this.ping = ping;
    }
    
    public void setSlot(final int slot) {
        this.slot = slot;
    }
    
    public void setText(final String text) {
        this.text = text;
    }
    
    public void setSkinTexture(final SkinTexture skinTexture) {
        this.skinTexture = skinTexture;
    }
}
