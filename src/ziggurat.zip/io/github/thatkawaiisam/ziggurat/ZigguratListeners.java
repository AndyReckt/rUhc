package io.github.thatkawaiisam.ziggurat;

import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import io.github.thatkawaiisam.ziggurat.utils.impl.*;
import org.bukkit.*;
import io.github.thatkawaiisam.utils.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import java.util.*;
import org.bukkit.scoreboard.*;

public class ZigguratListeners implements Listener
{
    private Ziggurat instance;
    
    public ZigguratListeners(final Ziggurat instance) {
        this.instance = instance;
    }
    
    @EventHandler
    public void onJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        this.instance.getTablists().put(player.getUniqueId(), new ZigguratTablist(player, this.instance));
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onQuit(final PlayerQuitEvent event) {
        final Player player = event.getPlayer();
        this.instance.getTablists().remove(player.getUniqueId());
    }
    
    @EventHandler
    public void onAsync(final AsyncPlayerPreLoginEvent event) {
        if (this.instance.getImplementation() instanceof v1_7TabImpl) {
            for (final Player loopPlayer : Bukkit.getOnlinePlayers()) {
                if (PlayerUtility.getPlayerVersion(loopPlayer) == PlayerVersion.v1_7) {
                    continue;
                }
                Team otherTeam = loopPlayer.getScoreboard().getTeam("\\u000181");
                if (otherTeam == null) {
                    otherTeam = loopPlayer.getScoreboard().registerNewTeam("\\u000181");
                }
                otherTeam.addEntry(event.getName());
            }
        }
    }
}
