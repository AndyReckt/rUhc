package io.github.thatkawaiisam.ziggurat;

import org.bukkit.entity.*;
import java.util.concurrent.*;
import org.bukkit.scheduler.*;
import io.github.thatkawaiisam.utils.*;
import org.bukkit.plugin.*;
import io.github.thatkawaiisam.utils.playerversion.*;
import org.bukkit.scoreboard.*;
import io.github.thatkawaiisam.ziggurat.utils.impl.*;
import com.comphenix.protocol.*;
import java.util.*;
import io.github.thatkawaiisam.ziggurat.utils.*;
import org.bukkit.*;

public class ZigguratTablist
{
    private Player player;
    private Scoreboard scoreboard;
    private Set<TabEntry> currentEntries;
    private Ziggurat instance;
    
    public ZigguratTablist(final Player player, final Ziggurat instance) {
        this.currentEntries = ConcurrentHashMap.newKeySet();
        this.player = player;
        this.instance = instance;
        if (instance.isHook() || player.getScoreboard() != Bukkit.getScoreboardManager().getMainScoreboard()) {
            this.scoreboard = player.getScoreboard();
        }
        else {
            this.scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        }
        player.setScoreboard(this.scoreboard);
        final ZigguratTablist localTab = this;
        new BukkitRunnable() {
            public void run() {
                ZigguratTablist.this.setup();
                if (PlayerUtility.getPlayerVersion(player) == PlayerVersion.v1_7) {
                    for (final Player loopPlayer : Bukkit.getOnlinePlayers()) {
                        ZigguratTablist.this.getInstance().getImplementation().destoryFakePlayer(localTab, new TabEntry(loopPlayer.getName(), loopPlayer.getUniqueId(), loopPlayer.getName(), localTab, ZigguratCommons.defaultTexture, TabColumn.LEFT, 1, 1, 1), loopPlayer.getName());
                        if (player.canSee(loopPlayer)) {
                            instance.getImplementation().recreatePlayer(localTab, loopPlayer);
                        }
                    }
                }
            }
        }.runTaskAsynchronously((Plugin)instance.getPlugin());
    }
    
    private void setup() {
        for (int possibleSlots = (PlayerUtility.getPlayerVersion(this.player) == PlayerVersion.v1_7) ? 60 : 80, i = 1; i <= possibleSlots; ++i) {
            if (this.scoreboard != null) {
                if (this.scoreboard == this.player.getScoreboard()) {
                    final TabColumn tabColumn = TabColumn.getFromSlot(this.player, i);
                    if (tabColumn != null) {
                        final TabEntry tabEntry = this.instance.getImplementation().createFakePlayer(this, "0" + ((i > 9) ? Integer.valueOf(i) : ("0" + i)) + "|Tab", tabColumn, tabColumn.getNumb(this.player, i), i);
                        if (PlayerVersionHandler.version.getPlayerVersion(this.player) == PlayerVersion.v1_7 || this.instance.getImplementation() instanceof v1_7TabImpl) {
                            Team team = this.player.getScoreboard().getTeam((String)LegacyClientUtils.teamNames.get(i - 1));
                            if (team != null) {
                                team.unregister();
                            }
                            team = this.player.getScoreboard().registerNewTeam((String)LegacyClientUtils.teamNames.get(i - 1));
                            team.setPrefix("");
                            team.setSuffix("");
                            team.addEntry((String)LegacyClientUtils.tabEntrys.get(i - 1));
                        }
                        this.currentEntries.add(tabEntry);
                    }
                }
            }
        }
        if (PlayerUtility.getPlayerVersion(this.player) != PlayerVersion.v1_7 && this.instance.getImplementation() instanceof v1_7TabImpl) {
            Team team2 = this.player.getScoreboard().getTeam("\\u000181");
            if (team2 == null) {
                team2 = this.player.getScoreboard().registerNewTeam("\\u000181");
            }
            for (final Player loopPlayer : Bukkit.getOnlinePlayers()) {
                team2.addEntry(loopPlayer.getName());
            }
        }
    }
    
    public void cleanup() {
        for (final TabEntry tabEntry : this.getCurrentEntries()) {
            if (PlayerVersionHandler.version.getPlayerVersion(this.player) == PlayerVersion.v1_7 || this.instance.getImplementation() instanceof v1_7TabImpl) {
                final Team team = this.player.getScoreboard().getTeam((String)LegacyClientUtils.teamNames.get(tabEntry.getRawSlot() - 1));
                if (team != null) {
                    team.unregister();
                }
            }
            boolean skip = false;
            if (this.instance.getImplementation() instanceof ProtocolLibTabImpl && (Bukkit.getPluginManager().getPlugin("ProtocolLib") == null || !Bukkit.getPluginManager().getPlugin("ProtocolLib").isEnabled() || ProtocolLibrary.getProtocolManager() == null)) {
                skip = true;
            }
            if (!skip) {
                this.getInstance().getImplementation().destoryFakePlayer(this, tabEntry, null);
            }
        }
        if (!this.getInstance().isHook()) {
            this.player.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        }
    }
    
    public void update() {
        final Set<TabEntry> previous = new HashSet<TabEntry>(this.currentEntries);
        Set<BufferedTabObject> processedObjects = this.instance.getAdapter().getSlots(this.player);
        if (this.instance.getAdapter().getSlots(this.player) == null) {
            processedObjects = new HashSet<BufferedTabObject>();
        }
        for (final BufferedTabObject scoreObject : processedObjects) {
            final TabEntry tabEntry = this.getEntry(scoreObject.getColumn(), scoreObject.getSlot());
            if (tabEntry != null) {
                previous.remove(tabEntry);
                this.updateTabEntry(tabEntry, scoreObject);
            }
        }
        for (final TabEntry tabEntry2 : previous) {
            this.updateTabEntry(tabEntry2, null);
        }
        previous.clear();
        if (PlayerUtility.getPlayerVersion(this.player) != PlayerVersion.v1_7 && (this.instance.getAdapter().getHeader() != null || this.instance.getAdapter().getFooter() != null)) {
            final String header = (this.instance.getAdapter().getHeader() == null) ? "" : this.instance.getAdapter().getHeader();
            final String footer = (this.instance.getAdapter().getFooter() == null) ? "" : this.instance.getAdapter().getFooter();
            this.instance.getImplementation().updateHeaderAndFooter(this, header, footer);
        }
        if (this.player.getScoreboard() != this.scoreboard && !this.getInstance().isHook()) {
            this.player.setScoreboard(this.scoreboard);
        }
    }
    
    private void updateTabEntry(final TabEntry tabEntry, final BufferedTabObject tabObject) {
        if (PlayerUtility.getPlayerVersion(this.player) != PlayerVersion.v1_7) {
            this.updateFakeSkin(tabEntry, (tabObject == null) ? ZigguratCommons.defaultTexture : tabObject.getSkinTexture());
        }
        this.updateName(tabEntry, (tabObject == null) ? "" : tabObject.getText());
        this.updateLatency(tabEntry, (tabObject == null || tabObject.getPing() == null) ? this.getInstance().getPingProvider().getDefaultPing(this.player) : ((int)tabObject.getPing()));
    }
    
    private void updateFakeSkin(final TabEntry tabEntry, final SkinTexture skinTexture) {
        if (tabEntry.getTexture().toString().equals(skinTexture.toString())) {
            return;
        }
        this.instance.getImplementation().updateFakeSkin(this, tabEntry, skinTexture);
    }
    
    private void updateLatency(final TabEntry tabEntry, final int latency) {
        if (tabEntry.getLatency() == latency) {
            return;
        }
        this.instance.getImplementation().updateFakeLatency(this, tabEntry, latency);
    }
    
    private void updateName(final TabEntry tabEntry, final String string) {
        if (tabEntry.getText().equals(string)) {
            return;
        }
        this.instance.getImplementation().updateFakeName(this, tabEntry, string);
    }
    
    public TabEntry getEntry(final TabColumn column, final Integer slot) {
        for (final TabEntry entry : this.currentEntries) {
            if (entry.getColumn().name().equalsIgnoreCase(column.name()) && entry.getSlot() == slot) {
                return entry;
            }
        }
        return null;
    }
    
    public static String[] splitStrings(final String text) {
        if (text.length() <= 16) {
            return new String[] { text, "" };
        }
        String prefix = text.substring(0, 16);
        String suffix;
        if (prefix.charAt(15) == '§' || prefix.charAt(15) == '&') {
            prefix = prefix.substring(0, 15);
            suffix = text.substring(15, text.length());
        }
        else if (prefix.charAt(14) == '§' || prefix.charAt(14) == '&') {
            prefix = prefix.substring(0, 14);
            suffix = text.substring(14, text.length());
        }
        else {
            suffix = ChatColor.getLastColors(ChatColor.translateAlternateColorCodes('&', prefix)) + text.substring(16, text.length());
        }
        if (suffix.length() > 16) {
            suffix = suffix.substring(0, 16);
        }
        return new String[] { prefix, suffix };
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    public Scoreboard getScoreboard() {
        return this.scoreboard;
    }
    
    public Set<TabEntry> getCurrentEntries() {
        return this.currentEntries;
    }
    
    public Ziggurat getInstance() {
        return this.instance;
    }
}
