package io.github.thatkawaiisam.ziggurat;

import org.bukkit.plugin.java.*;
import io.github.thatkawaiisam.ziggurat.utils.*;
import io.github.thatkawaiisam.ziggurat.utils.ping.*;
import java.util.concurrent.*;
import io.github.thatkawaiisam.utils.*;
import io.github.thatkawaiisam.utils.serverversion.*;
import org.bukkit.*;
import io.github.thatkawaiisam.ziggurat.utils.impl.*;
import io.github.thatkawaiisam.ziggurat.utils.ping.impl.*;
import org.bukkit.plugin.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.event.*;

public class Ziggurat
{
    private JavaPlugin plugin;
    private ZigguratAdapter adapter;
    private Map<UUID, ZigguratTablist> tablists;
    private ZigguratThread thread;
    private IZigguratHelper implementation;
    private ZigguratListeners listeners;
    private long ticks;
    private boolean hook;
    private IPingProvider pingProvider;
    
    public Ziggurat(final JavaPlugin plugin, final ZigguratAdapter adapter) {
        this.ticks = 20L;
        this.hook = false;
        if (plugin == null) {
            throw new RuntimeException("Ziggurat can not be instantiated without a plugin instance!");
        }
        this.plugin = plugin;
        this.adapter = adapter;
        this.tablists = new ConcurrentHashMap<UUID, ZigguratTablist>();
        UtilityManager.init();
        this.registerImplementation();
        this.registerPingImplementation();
        this.setup();
    }
    
    private void registerImplementation() {
        if (ServerVersionHandler.serverVersionName.contains("1_7")) {
            this.implementation = new v1_7TabImpl();
            this.plugin.getLogger().info("[ZIGGURAT] Registered Implementation with 1.7 Protocol");
            return;
        }
        if (Bukkit.getPluginManager().getPlugin("ProtocolLib") != null) {
            this.implementation = new ProtocolLibTabImpl();
            this.plugin.getLogger().info("[ZIGGURAT] Registered Implementation with ProtocolLib");
            return;
        }
        this.plugin.getLogger().info("[ZIGGURAT] Unable to register Ziggurat with a proper implementation");
    }
    
    private void registerPingImplementation() {
        if (Bukkit.getPluginManager().getPlugin("LunarClientAPI") != null) {
            this.pingProvider = new LunarPingImpl();
            this.plugin.getLogger().info("[ZIGGURAT] Successfully hooked into LunarClientAPI.");
        }
        else {
            this.pingProvider = new DefaultPingImpl();
        }
    }
    
    private void setup() {
        this.plugin.getServer().getPluginManager().registerEvents((Listener)(this.listeners = new ZigguratListeners(this)), (Plugin)this.plugin);
        if (this.thread != null) {
            this.thread.stop();
            this.thread = null;
        }
        for (final Player player : Bukkit.getOnlinePlayers()) {
            if (this.getTablists().containsKey(player.getUniqueId())) {
                continue;
            }
            this.getTablists().put(player.getUniqueId(), new ZigguratTablist(player, this));
        }
        this.thread = new ZigguratThread(this);
    }
    
    public void disable() {
        if (this.thread != null) {
            this.thread.stop();
            this.thread = null;
        }
        if (this.listeners != null) {
            HandlerList.unregisterAll((Listener)this.listeners);
            this.listeners = null;
        }
        for (final UUID uuid : this.getTablists().keySet()) {
            this.getTablists().get(uuid).cleanup();
        }
        this.getTablists().clear();
        this.implementation = null;
        this.pingProvider = null;
    }
    
    public JavaPlugin getPlugin() {
        return this.plugin;
    }
    
    public ZigguratAdapter getAdapter() {
        return this.adapter;
    }
    
    public Map<UUID, ZigguratTablist> getTablists() {
        return this.tablists;
    }
    
    public ZigguratThread getThread() {
        return this.thread;
    }
    
    public IZigguratHelper getImplementation() {
        return this.implementation;
    }
    
    public ZigguratListeners getListeners() {
        return this.listeners;
    }
    
    public long getTicks() {
        return this.ticks;
    }
    
    public boolean isHook() {
        return this.hook;
    }
    
    public IPingProvider getPingProvider() {
        return this.pingProvider;
    }
    
    public void setTicks(final long ticks) {
        this.ticks = ticks;
    }
    
    public void setHook(final boolean hook) {
        this.hook = hook;
    }
    
    public void setPingProvider(final IPingProvider pingProvider) {
        this.pingProvider = pingProvider;
    }
}
